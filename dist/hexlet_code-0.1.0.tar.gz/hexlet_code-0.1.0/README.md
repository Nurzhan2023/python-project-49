### Hexlet tests and linter status:
[![Actions Status](https://github.com/Nurzhan2023/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Nurzhan2023/python-project-49/actions)


[![asciinema](https://asciinema.org/a/UJcIHje1AFGQW0jVLQIsPTvra.svg)](https://asciinema.org/a/UJcIHje1AFGQW0jVLQIsPTvra)

[![asciinema](https://asciinema.org/a/HvyBwauBSvLjuilTqCRT2Gbhn.svg)](https://asciinema.org/a/HvyBwauBSvLjuilTqCRT2Gbhn)

<a href="https://codeclimate.com/github/Nurzhan2023/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/364adb79c130f5d257e8/maintainability" /></a>

